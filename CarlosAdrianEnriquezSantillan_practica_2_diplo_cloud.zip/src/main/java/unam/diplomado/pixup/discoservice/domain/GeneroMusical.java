package unam.diplomado.pixup.discoservice.domain;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

public class GeneroMusical {
	private String id;
	private String descripcion;
}
