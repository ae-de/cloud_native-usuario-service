package unam.diplomado.pixup.discoservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
