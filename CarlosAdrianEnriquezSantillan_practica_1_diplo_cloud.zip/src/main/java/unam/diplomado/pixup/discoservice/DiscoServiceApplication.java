package unam.diplomado.pixup.discoservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiscoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiscoServiceApplication.class, args);
	}

}
